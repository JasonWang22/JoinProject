package Join.dao.Impl;

import Join.dao.CommodityDao;
import Join.dao.Sql.CommoditySql;
import Join.entity.Commodity;
import Join.entity.Page;
import Join.entity.Trolley;
import Join.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class CommodityDaoImpl implements CommodityDao {

    @Override
    public List<Commodity> slideShow() {
        List<Commodity> commodityList = new ArrayList<Commodity>();
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.slideShow);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Commodity commodity = new Commodity();
                commodity.setCommodityid(resultSet.getInt("commodityid"));
                commodity.setCommodityphoto(resultSet.getString("commodityphoto"));
                commodityList.add(commodity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return commodityList;
        }
    }

    @Override
    public int getTotalRecord() {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        int totalRecord = 0;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.getTotalRecord);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                totalRecord = resultSet.getInt("totalRecord");
                row++;
                if (row > 0 && totalRecord > 0) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return totalRecord;
    }

    @Override
    public List<Commodity> mainPageShow(Page page) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        List<Commodity> commodityList = new ArrayList<Commodity>();
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.mainPageShow);
            preparedStatement.setInt(1, page.getStartIndex());
            preparedStatement.setInt(2, page.getPageSize());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Commodity commodity = new Commodity();
                commodity.setCommodityid(resultSet.getInt("commodityid"));
                commodity.setCommodityname(resultSet.getString("commodityname"));
                commodity.setCommodityphoto(resultSet.getString("commodityphoto"));
                commodity.setCommodityprice(resultSet.getDouble("commodityprice"));
                commodityList.add(commodity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return commodityList;
    }

    @Override
    public List<Commodity> details(int id) {
        List<Commodity> commodityList = new ArrayList<Commodity>();
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        Connection connection = null;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.details);
            preparedStatement.setInt(1, id);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Commodity commodity = new Commodity();
                commodity.setCommodityid(resultSet.getInt("commodityid"));
                commodity.setCommodityname(resultSet.getString("commodityname"));
                commodity.setCommodityphoto(resultSet.getString("commodityphoto"));
                commodity.setCommoditystocks(resultSet.getInt("commoditystocks"));
                commodity.setCommodityprice(resultSet.getDouble("commodityprice"));
                commodity.setCommoditycharacteristics(resultSet.getString("commoditycharacteristics"));
                commodityList.add(commodity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return commodityList;
    }

    @Override
    public Commodity takeoutInformation(Trolley trolley) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        Commodity commodity = new Commodity();
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.details);
            preparedStatement.setInt(1, trolley.getCommodityid());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                commodity.setCommodityname(resultSet.getString("commodityname"));
                commodity.setCommodityphoto(resultSet.getString("commodityphoto"));
                commodity.setCommodityprice(resultSet.getDouble("commodityprice"));
                row++;
                if (row > 0) {
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return commodity;

    }

    public int putinTrolley(Trolley trolley) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.putinTrolley);
            preparedStatement.setInt(1, trolley.getCommodityid());
            preparedStatement.setString(2, trolley.getCommodityname());
            preparedStatement.setString(3, trolley.getCommodityphoto());
            preparedStatement.setDouble(4, trolley.getCommodityprice());
            preparedStatement.setInt(5, trolley.getCommoditynum());
            preparedStatement.setDouble(6, trolley.getCommoditypriceall());
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public List<Trolley> trolleyShow() {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        List<Trolley> trolleyList = new ArrayList<Trolley>();
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.trolleyShow);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Trolley trolley = new Trolley();
                trolley.setCommodityid(resultSet.getInt("commodityid"));
                trolley.setCommodityname((resultSet.getString("commodityname")));
                trolley.setCommodityphoto(resultSet.getString("commodityphoto"));
                trolley.setCommodityprice(resultSet.getDouble("commodityprice"));
                trolley.setCommoditynum(resultSet.getInt("commoditynum"));
                trolley.setCommoditypriceall(trolley.getCommodityprice(), trolley.getCommoditynum());
                trolleyList.add(trolley);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return trolleyList;
    }

    @Override
    public double getAllPrice() {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        double allprice = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.getAllPrice);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                allprice += resultSet.getDouble("allprice");
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return allprice;
    }

    @Override
    public int pay(String username, double allPrice) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, CommoditySql.pay);
            preparedStatement.setDouble(1,allPrice);
            preparedStatement.setString(2,username);
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public int emptyTrolley() {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection,CommoditySql.emptyTrolley );
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }
}
