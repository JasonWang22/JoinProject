package Join.service;

import Join.entity.Commodity;
import Join.entity.Page;
import Join.entity.Trolley;

import java.lang.ref.SoftReference;
import java.util.List;

public interface CommodityService {

    public List<Commodity> slideShow();

    public Page getPageInformation(Page page);

    public List<Commodity> mainPageShow(Page page);

    public List<Commodity> details(int id);

    public int putinTrolley(Trolley trolley);

    public List<Trolley> trolleyShow ();

    public double getAllPrice();

    public int pay(String username, double allPrice);

    public int emptyTrolley();

}
