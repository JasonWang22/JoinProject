package Join.service.Impl;

import Join.dao.CommodityDao;
import Join.dao.Impl.CommodityDaoImpl;
import Join.entity.Commodity;
import Join.entity.Page;
import Join.entity.Trolley;
import Join.service.CommodityService;

import java.util.List;

public class CommodityServiceImpl implements CommodityService {

    @Override
    public List<Commodity> slideShow() {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        return commodityDaoImpl.slideShow();
    }

    @Override
    public Page getPageInformation(Page page) {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        page.setTotalRecord(commodityDaoImpl.getTotalRecord());
        page.setPageSize(8);
        page.setTotalPage(page.getTotalRecord(), page.getPageSize());
        page.setStartIndex(page.getPageNum(), page.getPageSize());
        return page;
    }

    @Override
    public List<Commodity> mainPageShow(Page page) {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        return commodityDaoImpl.mainPageShow(page);
    }

    @Override
    public List<Commodity> details(int id) {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        return commodityDaoImpl.details(id);
    }

    @Override
    public int putinTrolley(Trolley trolley) {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        Commodity commodity = commodityDaoImpl.takeoutInformation(trolley);
        trolley.setCommodityname(commodity.getCommodityname());
        trolley.setCommodityphoto(commodity.getCommodityphoto());
        trolley.setCommodityprice(commodity.getCommodityprice());
        trolley.setCommoditypriceall(trolley.getCommodityprice(), trolley.getCommoditynum());
        return commodityDaoImpl.putinTrolley(trolley);
    }

    @Override
    public List<Trolley> trolleyShow() {
        CommodityDaoImpl commodityDaoImpl = new CommodityDaoImpl();
        return commodityDaoImpl.trolleyShow();
    }

    @Override
    public double getAllPrice() {
        CommodityDao commodityDao = new CommodityDaoImpl();
        return commodityDao.getAllPrice();
    }

    @Override
    public int pay(String username, double allPrice) {
        CommodityDao commodityDao = new CommodityDaoImpl();
        return commodityDao.pay(username, allPrice);
    }

    @Override
    public int emptyTrolley() {
        CommodityDao commodityDao = new CommodityDaoImpl();
        return commodityDao.emptyTrolley();
    }
}
