package Join.dao.Sql;

public class MerchantSql {

    public static String changeCommodityName = "update joincommodityinformation set commodityname =? where commodityid =?";

    public static String changeCommodityStocks = "update joincommodityinformation set commoditystocks =? where commodityid =?";

    public static String changeCommodityPrice = "update joincommodityinformation set commodityprice =? where commodityid =?";

    public static String changeCommodityCharacteristics = "update joincommodityinformation set commoditycharacteristics =? where commodityid =?";

    public static String show = "select * from joincommodityinformation";

    public static String soldOut = "delete from joincommodityinformation where commodityid =?";

    public static String putAwayCommodity = "insert into joincommodityinformation (commodityname, commodityphoto, commoditystocks, commodityprice, commoditycharacteristics) values (?,?,?,?,?)";

    public static String changeCommodityPhoto = "update joincommodityinformation set commodityphoto =? where commodityid =?";

}
