package Join.dao;

import Join.entity.UserAndMerchant;

public interface UserDao {

    public int login (UserAndMerchant user);

    public int register(UserAndMerchant user);

    public int cancel(UserAndMerchant user);

    public int change(String username, String filed, String informationChanged);

    public UserAndMerchant getUser(String username);

}
