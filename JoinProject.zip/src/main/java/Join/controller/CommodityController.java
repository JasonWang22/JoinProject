package Join.controller;

import Join.entity.Commodity;
import Join.entity.Page;
import Join.entity.Trolley;
import Join.entity.UserAndMerchant;
import Join.service.CommodityService;
import Join.service.Impl.CommodityServiceImpl;
import Join.utils.JsonUtil;
import Join.utils.TimeUtil;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommodityController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/Commodity/mainpageshow":
                doMainPageShow(request, response);
                break;
            case "/Commodity/details":
                doDetails(request, response);
                break;
            case "/Commodity/putintrolley":
                doPutInTrolley(request, response);
                break;
            default:
                doNull(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/Commodity/slideshow":
                doSlideShow(request, response);
                break;
            case "/Commodity/trolleyshow":
                doTrolleyShow(request, response);
                break;
            case "/Commodity/pay":
                doPay(request, response);
                break;
            case "/Commodity/getorder":
                    doGetOrder(request, response);
                    break;
            default:
                doNull(request, response);
        }
    }

    /**
     * 轮播图展示
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doSlideShow(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        CommodityService commodityService = new CommodityServiceImpl();
        List<Commodity> commodityList = commodityService.slideShow();

        Map map = new HashMap();
        if (commodityList != null) {
            map.put("code", 1);
            map.put("msg", "请求成功");
            map.put("data", commodityList);
        } else {
            map.put("code", 2);
            map.put("msg", "请求失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 主页分页展示
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doMainPageShow(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Page page = JsonUtil.fromJson(request, Page.class);

        CommodityService commodityService = new CommodityServiceImpl();
        page = commodityService.getPageInformation(page);
        List<Commodity> commodityList = commodityService.mainPageShow(page);

        Map map = new HashMap();
        if (commodityList != null) {
            map.put("code", 1);
            map.put("msg", "请求成功");
            map.put("data", commodityList);
            map.put("pageInformation", page);
        } else {
            map.put("code", 2);
            map.put("msg", "请求失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商品详情页
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doDetails(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Commodity commodity = JsonUtil.fromJson(request, Commodity.class);

        CommodityService commodityService = new CommodityServiceImpl();
        List<Commodity> commodityList = commodityService.details(commodity.getCommodityid());

        Map map = new HashMap();
        if (commodityList != null) {
            map.put("code", 1);
            map.put("msg", "请求成功");
            map.put("data", commodityList);
        } else {
            map.put("code", 2);
            map.put("msg", "请求失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 将商品放入购物车
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doPutInTrolley(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Trolley trolley = JsonUtil.fromJson(request, Trolley.class);

        CommodityService commodityService = new CommodityServiceImpl();
        int row = commodityService.putinTrolley(trolley);

        Map map = new HashMap();
        if (row > 0) {
            map.put("code", 1);
            map.put("msg", "加入购物车成功");
        } else {
            map.put("code", 2);
            map.put("msg", "加入购物车失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 购物车页面
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doTrolleyShow(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        CommodityService commodityService = new CommodityServiceImpl();
        List<Trolley> trolleyList = commodityService.trolleyShow();

        Map map = new HashMap();
        if (trolleyList != null) {
            double allPrice = commodityService.getAllPrice();
            map.put("code", 1);
            map.put("msg", "展示成功");
            map.put("data", trolleyList);
            map.put("allPrice", allPrice);
        } else {
            map.put("code", 2);
            map.put("msg", "展示失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 付款操作
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doPay(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        CommodityService commodityService = new CommodityServiceImpl();
        double allPrice = commodityService.getAllPrice();

        HttpSession httpSession = request.getSession(true);
        UserAndMerchant user = (UserAndMerchant) httpSession.getAttribute("user");

        int row = 0;
        try {
            row = 1 + 2 * (commodityService.pay(user.getUsername(), allPrice));
            row += commodityService.emptyTrolley();
        } catch (Exception e) {
             e.printStackTrace();
        }

        Map map = new HashMap();
        if (row == 4) {
            map.put("code", 1);
            map.put("msg", "付款成功");
        } else if (row == 3){
            map.put("code", 2);
            map.put("msg", "清空购物车失败，请稍后再试");
        } else if (row == 2) {
            map.put("code", 3);
            map.put("msg", "付款失败，请稍后再试");
        } else if (row == 1) {
            map.put("code", 4);
            map.put("msg", "付款或清空购物车失败，请稍后再试");
        } else if (row == 0) {
            map.put("code", 5);
            map.put("msg", "用户未登录，请登陆后再试");
        } else {
            map.put("code", 6);
            map.put("msg", "异常错误，请刷新后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 不存在
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doNull(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Map map = new HashMap();
        map.put("code", 999);
        map.put("msg", "该页面不存在!!!");

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();

    }

    /**
     * 生成订单
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doGetOrder(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        HttpSession httpSession = request.getSession();
        UserAndMerchant user = (UserAndMerchant) httpSession.getAttribute("user");

        Map map = new HashMap();
        int row = 0;
        try {
            String username = user.getUsername();
            row = 1;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            map.put("code",row);
        }
        if (row == 1) {
            map.put("msg","生成订单成功");
            map.put("time", TimeUtil.getCurrentDate());
        } else {
            map.put("msg","生成订单失败");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();

    }

}

