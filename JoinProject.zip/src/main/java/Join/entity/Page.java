package Join.entity;

public class Page {

    /**
     * 当前页码；前端传来
     */
    private int pageNum;

    /**
     * 每页多少条数据；代码中设定
     */
    private int pageSize;

    /**
     * 数据库总的数据条数；count语句得到
     */
    private int totalRecord;

    /**
     * 总页码数
     */
    private int totalPage;

    /**
     * 数据记录的起始位置，limit操作的第一个值
     */
    private int startIndex;

//    当前页码——前端传；直接赋  1

    public int getPageNum() {
        return pageNum;
    }

    public void setPageNum(int pageNum) {
        this.pageNum = pageNum;
    }

    //每页多少数据——自己在代码中设置；直接赋  1*

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    //数据总条数——SQL中获取；获取后赋值  1

    public int getTotalRecord() {
        return totalRecord;
    }

    public void setTotalRecord(int totalRecord) {
        this.totalRecord = totalRecord;
    }

    //总页码数——计算得来  1

    public int getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(int totalRecord, int pageSize) {
        if (totalRecord % pageSize == 0) {
            this.totalPage = totalRecord / pageSize;
        } else {
            this.totalPage = totalRecord / pageSize + 1;
        }
    }

    //每页数据起始位置——计算得来  1*

    public int getStartIndex() {
        return startIndex;
    }

    public void setStartIndex(int pageNum, int pageSize) {
        this.startIndex = (pageNum - 1) * pageSize;
    }

}
