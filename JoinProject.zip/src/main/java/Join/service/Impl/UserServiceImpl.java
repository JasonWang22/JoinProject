package Join.service.Impl;

import Join.dao.Impl.UserDaoImpl;
import Join.entity.UserAndMerchant;
import Join.service.UserService;

public class UserServiceImpl implements UserService {

    @Override
    public int login(UserAndMerchant user) {
        //在数据库中进行对比
        UserDaoImpl userDaoImpl = new UserDaoImpl();
        return userDaoImpl.login(user);
    }

    @Override
    public int register(UserAndMerchant user) {
        //存入数据库
        UserDaoImpl userDaoImpl = new UserDaoImpl();
        return userDaoImpl.register(user);
    }

    @Override
    public int cancel(UserAndMerchant user) {
        //删除该记录
        UserDaoImpl userDaoImpl = new UserDaoImpl();
        return userDaoImpl.cancel(user);
    }

    @Override
    public int change(UserAndMerchant pastUser, UserAndMerchant changeUser) {
        //修改该记录
        int shouldChangeNum = 0;
        int changeNum = 0;
        String filed = null;
        String username = pastUser.getUsername();
        //修改该记录
        UserDaoImpl userDaoImpl = new UserDaoImpl();
        if ((changeUser.getUsername() != null) && (!(changeUser.getUsername().equals("")))) {
            shouldChangeNum++;
            filed = "username";
            changeNum += userDaoImpl.change(username, filed, changeUser.getUsername());
            username = changeUser.getUsername();
        }
        if ((changeUser.getRealname() != null) && (!(changeUser.getRealname().equals("")))) {
            shouldChangeNum++;
            filed = "realname";
            changeNum += userDaoImpl.change(username, filed, changeUser.getRealname());
        }
        if ((changeUser.getQqmail() != null) && (!(changeUser.getQqmail().equals("")))) {
            shouldChangeNum++;
            filed = "qqmail";
            changeNum += userDaoImpl.change(username, filed, changeUser.getQqmail());
        }
        if ((changeUser.getTel() != null) && (!(changeUser.getTel().equals("")))) {
            shouldChangeNum++;
            filed = "tel";
            changeNum += userDaoImpl.change(username, filed, changeUser.getTel());
        }
        if ((changeUser.getPassword() != null) && (!(changeUser.getPassword().equals("")))) {
            shouldChangeNum++;
            filed = "password";
            changeNum += userDaoImpl.change(username, filed, changeUser.getPassword());
        }
        if ((changeUser.getUserheadportrait() != null) && (!(changeUser.getUserheadportrait().equals("")))) {
            shouldChangeNum++;
            filed = "userheadportrait";
            changeNum += userDaoImpl.change(username, filed, changeUser.getUserheadportrait());
        }
        if ((shouldChangeNum != changeNum) || (changeNum == 0)) {
            return 0;
        } else {
            return 1;
        }
    }

    @Override
    public UserAndMerchant getUser(String username) {
        //取出用户信息
        UserDaoImpl userDaoImpl = new UserDaoImpl();
        return userDaoImpl.getUser(username);
    }

}
