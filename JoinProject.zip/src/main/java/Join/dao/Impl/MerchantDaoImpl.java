package Join.dao.Impl;

import Join.dao.MerchantDao;
import Join.dao.Sql.MerchantSql;
import Join.entity.Commodity;
import Join.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MerchantDaoImpl implements MerchantDao {

    @Override
    public int change(int id, String filed, Commodity commodity) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            switch (filed) {
                case "commodityname":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.changeCommodityName);
                    preparedStatement.setString(1, commodity.getCommodityname());
                    break;
                case "commoditystocks":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.changeCommodityStocks);
                    preparedStatement.setInt(1, commodity.getCommoditystocks());
                    break;
                case "commodityprice":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.changeCommodityPrice);
                    preparedStatement.setDouble(1, commodity.getCommodityprice());
                    break;
                case "commoditycharacteristics":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.changeCommodityCharacteristics);
                    preparedStatement.setString(1, commodity.getCommoditycharacteristics());
                    break;
            }
            preparedStatement.setInt(2, id);
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public List<Commodity> show() {
        List<Commodity> commodityList = new ArrayList<Commodity>();
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.show);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Commodity commodity = new Commodity();
                commodity.setCommodityid(resultSet.getInt("commodityid"));
                commodity.setCommodityname(resultSet.getString("commodityname"));
                commodity.setCommodityphoto(resultSet.getString("commodityphoto"));
                commodity.setCommoditystocks(resultSet.getInt("commoditystocks"));
                commodity.setCommodityprice(resultSet.getDouble("commodityprice"));
                commodity.setCommoditycharacteristics(resultSet.getString("commoditycharacteristics"));
                commodityList.add(commodity);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return commodityList;
    }

    @Override
    public int soldOut(int commodityid) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.soldOut);
            preparedStatement.setInt(1, commodityid);
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public int putAwayCommodity(Commodity commodity) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.putAwayCommodity);
            preparedStatement.setString(1, commodity.getCommodityname());
            preparedStatement.setString(2, commodity.getCommodityphoto());
            preparedStatement.setInt(3, commodity.getCommoditystocks());
            preparedStatement.setDouble(4, commodity.getCommodityprice());
            preparedStatement.setString(5, commodity.getCommoditycharacteristics());
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return row;
        }
    }

    @Override
    public int changeCommodityPhoto(Commodity commodity) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, MerchantSql.changeCommodityPhoto);
            preparedStatement.setString(1, commodity.getCommodityphoto());
            preparedStatement.setInt(2, commodity.getCommodityid());
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

}
