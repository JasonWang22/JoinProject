package Join.dao;

import Join.entity.Commodity;

import java.util.List;

public interface MerchantDao {

    public int change(int id, String filed, Commodity commodity);

    public List<Commodity> show();

    public int soldOut(int commodityid);

    public int putAwayCommodity(Commodity commodity);

    public int changeCommodityPhoto(Commodity commodity);

}
