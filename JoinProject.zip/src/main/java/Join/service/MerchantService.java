package Join.service;

import Join.entity.Commodity;

import java.util.List;

public interface MerchantService {

    /**
     * 修改商品信息
     *
     * @param commodity
     * @return
     */
    public Boolean change(Commodity commodity);

    public List<Commodity> show();

    public int soldOut(int commodityid);

    public int putAwayCommodity (Commodity commodity);

    public int changeCommodityPhoto (Commodity commodity);

}
