package Join.service;

import Join.entity.Commodity;
import Join.entity.UserAndMerchant;

public interface UserService {

    /**
     * 用户登录
     *
     * @param user
     * @return
     */
    public int login(UserAndMerchant user);

    /**
     * 用户注册
     * @param user
     * @return
     */
    public int register(UserAndMerchant user);

    /**
     * 用户登出
     * @param user
     * @return
     */
    public int cancel(UserAndMerchant user);

    /**
     * 用户修改信息
     * @param pastUser
     * @param changeUser
     * @return
     */
    public int change(UserAndMerchant pastUser, UserAndMerchant changeUser);

    /**
     * 返回修改后的用户信息
     * @param username
     * @return
     */
    public UserAndMerchant getUser(String username);

}
