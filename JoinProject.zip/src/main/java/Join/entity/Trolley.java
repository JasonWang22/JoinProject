package Join.entity;

public class Trolley {

    private int commodityid;

    private String commodityname;

    private String commodityphoto;

    private double commodityprice;

    private int commoditynum;

    private double commoditypriceall;

    public int getCommodityid() {
        return commodityid;
    }

    public void setCommodityid(int commodityid) {
        this.commodityid = commodityid;
    }

    public String getCommodityname() {
        return commodityname;
    }

    public void setCommodityname(String commodityname) {
        this.commodityname = commodityname;
    }

    public String getCommodityphoto() {
        return commodityphoto;
    }

    public void setCommodityphoto(String commodityphoto) {
        this.commodityphoto = commodityphoto;
    }

    public double getCommodityprice() {
        return commodityprice;
    }

    public void setCommodityprice(double commodityprice) {
        this.commodityprice = commodityprice;
    }

    public int getCommoditynum() {
        return commoditynum;
    }

    public void setCommoditynum(int commoditynum) {
        this.commoditynum = commoditynum;
    }

    public double getCommoditypriceall() {
        return commoditypriceall;
    }

    public void setCommoditypriceall(double commodityprice, int commoditynum) {
        this.commoditypriceall = commodityprice * commoditynum;
    }
}
