package Join.dao.Sql;

public class CommoditySql {

    public static String slideShow = "select * from joinslideshow";

    public static String getTotalRecord = "select count(*) as totalRecord from joincommodityinformation";

    public static String mainPageShow = "select * from joincommodityinformation limit ? , ?";

    public static String details = "select * from joincommodityinformation where commodityid =?";

    public static String putinTrolley = "insert into joinshoppingtrolley(commodityid, commodityname, commodityphoto, commodityprice, commoditynum, commoditypriceall) values(?,?,?,?,?,?)";

    public static String trolleyShow = "select * from joinshoppingtrolley";

    public static String getAllPrice = "select sum(commoditypriceall) as allprice from joinshoppingtrolley";

    public static String pay = "update joinuser set spend =? where username =?";

    public static String emptyTrolley = "delete from joinshoppingtrolley";

}
