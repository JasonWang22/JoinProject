package Join.controller;

import Join.entity.Commodity;
import Join.service.Impl.MerchantServiceImpl;
import Join.service.MerchantService;
import Join.utils.JsonUtil;
import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class MerchantController extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/Merchant/change":
                doChange(request, response);
                break;
            case "/Merchant/putawayphoto":
                doPutAwayPhoto(request, response);
                break;
            case "/Merchant/putawaycommodity":
                doPutAwayCommodity(request, response);
                break;
            case "/Merchant/soldout":
                doSoldOut(request, response);
                break;
            case "/Merchant/changephototosave":
                doChangePhotoToSave(request, response);
                break;
            case "/Merchant/changephototochange":
                doChangePhotoToChange(request, response);
                break;
            default:
                doNull(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/Merchant/show":
                doShowForSaller(request, response);
                break;
            default:
                doNull(request, response);
        }
    }

    /**
     * 商家修改商品信息（除图片）
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doChange(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Commodity commodity = JsonUtil.fromJson(request, Commodity.class);

        MerchantService merchantService = new MerchantServiceImpl();
        Boolean successOrFailure = merchantService.change(commodity);

        Map map = new HashMap();
        if (successOrFailure) {
            map.put("code", 1);
            map.put("msg", "修改成功");
        } else {
            map.put("code", 2);
            map.put("msg", "修改失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商家对已上架商品的操作页面
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doShowForSaller(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        MerchantService merchantService = new MerchantServiceImpl();
        List<Commodity> commodityList = merchantService.show();

        Map map = new HashMap();
        if (commodityList != null) {
            map.put("code", 1);
            map.put("msg", "展示成功");
            map.put("data", commodityList);
        } else {
            map.put("code", 2);
            map.put("msg", "展示失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 上传商品信息时，用于返回上传的图片的url
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doPutAwayPhoto(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //key
        Part part = request.getPart("commodityphoto");

        //获取上传的文件名扩展名
        String disposition = part.getSubmittedFileName();
        String suffix = disposition.substring(disposition.lastIndexOf("."));

        //随机的生成uuid,，用于标识唯一的文件，并生成存放文件的目录，不存在目录则新建一个
        String filename = UUID.randomUUID() + suffix;
        String serverpath = request.getServletContext().getRealPath("CommodityPhoto");
        File fileDisk = new File(serverpath);
        if (!fileDisk.exists()) {
            fileDisk.mkdir();
        }

        //构建文件的绝对路径，存入字符串中
        String fileparts = serverpath + "/" + filename;
        part.write(fileparts);
        String projectServerPath = request.getScheme() + "://" + request.getServerName() + ":"
                + request.getServerPort() + request.getContextPath() + "/CommodityPhoto/" + filename;

        //构建返回值
        Map map = new HashMap();
        if (projectServerPath != null) {
            map.put("code", 1);
            map.put("msg", "上传商品图片成功");
            map.put("image", projectServerPath);
        } else {
            map.put("code", 2);
            map.put("msg", "上传商品图片失败，请稍后再试");
        }

        //将图片路径传回给前端
        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商品上架
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doPutAwayCommodity(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Commodity commodity = JsonUtil.fromJson(request, Commodity.class);

        MerchantService merchantService = new MerchantServiceImpl();
        int row = merchantService.putAwayCommodity(commodity);

        Map map = new HashMap();
        if (row > 0) {
            map.put("code", 1);
            map.put("msg", "上架商品成功");
        } else {
            map.put("code", 2);
            map.put("msg", "上架商品失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商品下架
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doSoldOut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Commodity commodity = JsonUtil.fromJson(request, Commodity.class);

        MerchantService merchantService = new MerchantServiceImpl();
        int row = merchantService.soldOut(commodity.getCommodityid());

        Map map = new HashMap();
        if (row > 0) {
            map.put("code", 1);
            map.put("msg", "下架成功");
        } else {
            map.put("code", 2);
            map.put("msg", "下架失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商家修改商品图片（获取地址，保存在本地）
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doChangePhotoToSave(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //key
        Part part = request.getPart("changephoto");

        //获取上传的文件名扩展名
        String disposition = part.getSubmittedFileName();
        String suffix = disposition.substring(disposition.lastIndexOf("."));

        //随机的生成uuid,，用于标识唯一的文件，并生成存放文件的目录，不存在目录则新建一个
        String filename = UUID.randomUUID() + suffix;
        String serverpath = request.getServletContext().getRealPath("CommodityPhoto");
        File fileDisk = new File(serverpath);
        if (!fileDisk.exists()) {
            fileDisk.mkdir();
        }

        //构建文件的绝对路径，存入字符串中
        String fileparts = serverpath + "/" + filename;
        part.write(fileparts);
        String projectServerPath = request.getScheme() + "://" + request.getServerName() + ":"
                + request.getServerPort() + request.getContextPath() + "/CommodityPhoto/" + filename;

        Map map = new HashMap();
        if (projectServerPath != null) {
            map.put("code", 1);
            map.put("msg", "上传成功");
            map.put("image", projectServerPath);
        } else {
            map.put("code", 2);
            map.put("msg", "上传失败，请稍后再试");
        }

        //将图片路径传回给前端
        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 商家修改商品图片（将地址存入数据库）
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doChangePhotoToChange(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Commodity commodity = JsonUtil.fromJson(request, Commodity.class);

        MerchantService merchantService = new MerchantServiceImpl();
        int row = merchantService.changeCommodityPhoto(commodity);

        Map map = new HashMap();
        if (row > 0) {
            map.put("code", 1);
            map.put("msg", "修改成功");
        } else {
            map.put("code", 2);
            map.put("msg", "修改失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 不存在
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doNull(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Map map = new HashMap();
        map.put("code", 999);
        map.put("msg", "该页面不存在!!!");

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
    }

}
