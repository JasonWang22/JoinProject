package Join.utils;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;

import java.io.InputStream;
import java.sql.*;
import java.util.Properties;

public class DruidUtil {

    /**
     * 生成DataSource的实例
     */
    public static DruidDataSource dataSource;

    static {
        Properties prop = new Properties();
        InputStream is = DruidUtil.class
                .getClassLoader()
                .getResourceAsStream("druid.properties");
        try {
            prop.load(is);
            dataSource = (DruidDataSource) DruidDataSourceFactory.createDataSource(prop);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 工具类私有构造方法
     */
    private DruidUtil() {
    }

    //从连接池中获取Connection
    public static Connection getConnection() {
        Connection conn = null;
        try {
            conn = dataSource.getConnection();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("获取连接池Connection对象失败");
        }
        return conn;
    }

    //获取连接池Statement
    public static Statement getStatement(Connection conn) {
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("获取连接池Statment对象失败");
        }
        return stmt;
    }

    //获取连接池PreparedStatement对象
    public static PreparedStatement getPreparedStatement(Connection conn, String sql) {
        PreparedStatement ps = null;
        try {
            ps = conn.prepareStatement(sql);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println("获取连接池PreparedStatment对象失败");
        }
        return ps;
    }

    //释放连接回连接池
    public static void releaseDql(Statement stmt, ResultSet rs, Connection conn) {
        if (rs != null) {
            try {
                rs.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            rs = null;
        }
        if (stmt != null) {
            try {
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            stmt = null;
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            conn = null;
        }
    }

    public static void releaseDml(Statement stmt, Connection conn) {
        if (stmt != null) {
            try {
                stmt.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            stmt = null;
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            conn = null;
        }
    }

}
