package Join.entity;

public class Commodity {

    private int commodityid;

    private String commodityname;

    private String commodityphoto;

    private int commoditystocks;

    private double commodityprice;

    private String commoditycharacteristics;

    public int getCommodityid() {
        return commodityid;
    }

    public void setCommodityid(int commodityid) {
        this.commodityid = commodityid;
    }

    public String getCommodityname() {
        return commodityname;
    }

    public void setCommodityname(String commodityname) {
        this.commodityname = commodityname;
    }

    public String getCommodityphoto() {
        return commodityphoto;
    }

    public void setCommodityphoto(String commodityphoto) {
        this.commodityphoto = commodityphoto;
    }

    public int getCommoditystocks() {
        return commoditystocks;
    }

    public void setCommoditystocks(int commoditystocks) {
        this.commoditystocks = commoditystocks;
    }

    public double getCommodityprice() {
        return commodityprice;
    }

    public void setCommodityprice(double commodityprice) {
        this.commodityprice = commodityprice;
    }

    public String getCommoditycharacteristics() {
        return commoditycharacteristics;
    }

    public void setCommoditycharacteristics(String commoditycharacteristics) {
        this.commoditycharacteristics = commoditycharacteristics;
    }

}
