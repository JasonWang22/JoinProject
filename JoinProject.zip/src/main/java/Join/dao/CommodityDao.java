package Join.dao;

import Join.entity.Commodity;
import Join.entity.Page;
import Join.entity.Trolley;

import java.util.List;

public interface CommodityDao {

    public List<Commodity> slideShow();

    public int getTotalRecord();

    public List<Commodity> mainPageShow(Page page);

    public List<Commodity> details(int id);

    public Commodity takeoutInformation(Trolley trolley);

    public List<Trolley> trolleyShow();

    public double getAllPrice();

    public int pay(String username, double allPrice);

    public int emptyTrolley();

}
