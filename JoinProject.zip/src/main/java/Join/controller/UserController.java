package Join.controller;

import Join.entity.UserAndMerchant;
import Join.service.Impl.UserServiceImpl;
import Join.service.UserService;
import Join.utils.JsonUtil;

import com.google.gson.Gson;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.*;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@MultipartConfig
public class UserController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/User/login":
                doLogin(request, response);
                break;
            case "/User/register":
                doRegister(request, response);
                break;
            case "/User/changeuserheadportrait":
                doChangeUserHeadportrait(request, response);
                break;
            case "/User/change":
                doChange(request, response);
                break;
            default:
                doNull(request, response);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String uri = request.getRequestURI();
        switch (uri) {
            case "/User/logout":
                doLogout(request, response);
                break;
            case "/User/cancel":
                doCancel(request, response);
                break;
            case "/User/getuser":
                doGetUser(request, response);
                break;
            default:
                doNull(request, response);
        }
    }

    /**
     * 用户登录
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        //反序列化  Json字符串 ----> Java实体
        UserAndMerchant user = JsonUtil.fromJson(request, UserAndMerchant.class);

        //逻辑处理
        UserService userService = new UserServiceImpl();
        int user1 = userService.login(user);

        //构建返回值
        Map map = new HashMap();
        if (user1 == 0) {
            map.put("code", user1);
            map.put("msg", "该用户不存在，请输入正确的用户名");

        } else if (user1 == 1) {
            map.put("code", user1);
            map.put("msg", "密码错误，请输入正确的密码");
        } else {
            UserAndMerchant user2 = userService.getUser(user.getUsername());
            HttpSession httpSession = request.getSession();
            httpSession.setAttribute("user", user2);
            if ("join".equals(user2.getUsername())) {
                user1++;
            }
            if (user1 == 2) {
                map.put("code", user1);
                map.put("msg", "登录成功");
                map.put("data", user2);
            } else if (user1 == 3) {
                map.put("code", user1);
                map.put("msg", "卖家登录成功");
                map.put("data", user2);
            } else {
                map.put("code",4);
                map.put("msg","异常错误，请稍后再试");
            }
        }

        //Gson序列化，并使用Json将返回值数据返回给前端
        Gson gson = new Gson();

        //序列化  Java实体 ----> Json字符串
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 用户注册
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doRegister(HttpServletRequest request, HttpServletResponse response) throws IOException {

        UserAndMerchant user = JsonUtil.fromJson(request, UserAndMerchant.class);

        UserService userService = new UserServiceImpl();
        int row = userService.register(user);

        Map map = new HashMap();
        if (row != 0) {
            map.put("code", 1);
            map.put("msg", "注册成功，请返回登录界面进行登录");
        } else {
            map.put("code", 2);
            map.put("msg", "该用户已注册，请勿重复注册");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 用户登出
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doLogout(HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession httpSession = request.getSession();
        httpSession.invalidate();

        Map map = new HashMap();
        if (request.getSession(false) == null) {
            map.put("code", 1);
            map.put("msg", "登出成功");
        } else {
            map.put("code", 2);
            map.put("msg", "登出失败，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 用户注销
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doCancel(HttpServletRequest request, HttpServletResponse response) throws IOException {

        HttpSession httpSession = request.getSession();
        UserAndMerchant user = (UserAndMerchant) httpSession.getAttribute("user");

        UserService userService = new UserServiceImpl();
        int row = userService.cancel(user);

        Map map = new HashMap();
        if (row != 0) {
            map.put("code", 1);
            map.put("msg", "注销成功");
        } else {
            map.put("code", 2);
            map.put("msg", "注销失败，请稍后再试");
        }

        httpSession.invalidate();

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 用户信息修改
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doChange(HttpServletRequest request, HttpServletResponse response) throws IOException {

        UserAndMerchant changeUser = JsonUtil.fromJson(request, UserAndMerchant.class);

        HttpSession httpSession = request.getSession();
        UserAndMerchant pastUser = (UserAndMerchant) httpSession.getAttribute("user");

        UserService userService = new UserServiceImpl();
        int row = userService.change(pastUser, changeUser);

        Map map = new HashMap();
        String username = null;
        if (row > 0) {
            if (changeUser.getUsername() != null) {
                username = changeUser.getUsername();
            } else {
                username = pastUser.getUsername();
            }
            UserAndMerchant user = userService.getUser(username);
            map.put("code", 1);
            map.put("msg", "修改成功");
            map.put("data", user);
            httpSession.setAttribute("user", user);
        } else {
            map.put("code", 2);
            map.put("msg", "未修改任何信息或修改时出错，请查看自己个人信息后稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 用户修改头像，用于返回url
     *
     * @param request
     * @param response
     * @throws IOException
     */
    private void doChangeUserHeadportrait(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {

        //key
        Part part = request.getPart("img");

        //获取上传的文件名扩展名
        String disposition = part.getSubmittedFileName();
        String suffix = disposition.substring(disposition.lastIndexOf("."));

        //随机的生成uuid,，用于标识唯一的文件，并生成存放文件的目录，不存在目录则新建一个
        String filename = UUID.randomUUID() + suffix;
        String serverpath = request.getServletContext().getRealPath("UserHeadprotrait");
        File fileDisk = new File(serverpath);
        if (!fileDisk.exists()) {
            fileDisk.mkdir();
        }

        //构建文件的绝对路径，存入字符串中
        String fileparts = serverpath + "/" + filename;
        part.write(fileparts);
        String projectServerPath = request.getScheme() + "://" + request.getServerName() + ":"
                + request.getServerPort() + request.getContextPath() + "/UserHeadprotrait/" + filename;

        //构建返回值
        Map map = new HashMap();
        if (projectServerPath != null) {
            map.put("code", 1);
            map.put("msg", "修改头像成功");
            map.put("image", projectServerPath);
        } else {
            map.put("code", 2);
            map.put("msg", "修改头像失败，请稍后再试");
        }

        //将图片路径传回给前端
        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 展示用户信息
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doGetUser(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {

        HttpSession httpSession = request.getSession();
        UserAndMerchant user = (UserAndMerchant) httpSession.getAttribute("user");

        Map map = new HashMap();
        if (user != null) {
            map.put("code", 1);
            map.put("msg", "成功");
            map.put("data", user);
        } else {
            map.put("code", 2);
            map.put("msg", "出错了，请稍后再试");
        }

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter printWriter = response.getWriter();
        printWriter.println(jsonString);
        printWriter.flush();

    }

    /**
     * 不存在
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    private void doNull(HttpServletRequest request, HttpServletResponse response) throws
            ServletException, IOException {

        Map map = new HashMap();
        map.put("code", 999);
        map.put("msg", "该页面不存在!!!");

        Gson gson = new Gson();
        String jsonString = gson.toJson(map);
        PrintWriter out = response.getWriter();
        out.print(jsonString);
        out.flush();
    }

}
