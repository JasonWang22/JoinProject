package Join.utils;

import com.google.gson.Gson;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Map;

public class JsonUtil {
    public static <T> T fromJson(HttpServletRequest request, Class<T> tClass) {
        try {
            String jsonString = null;
            StringBuilder stringBuilder = new StringBuilder();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(request.getInputStream(), "UTF-8"));
            String str = null;
            while ((str = bufferedReader.readLine()) != null) {
                stringBuilder.append(str);
            }
            jsonString = stringBuilder.toString();
            bufferedReader.close();
            Gson gson = new Gson();
            return gson.fromJson(jsonString, tClass);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
