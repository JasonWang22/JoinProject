package Join.service.Impl;

import Join.dao.Impl.MerchantDaoImpl;
import Join.entity.Commodity;
import Join.service.MerchantService;

import java.util.List;

public class MerchantServiceImpl implements MerchantService {

    @Override
    public Boolean change(Commodity commodity) {
        //修改该记录
        int shouldChangeNum = 0;
        int changeNum = 0;
        MerchantDaoImpl merchantDaoImpl = new MerchantDaoImpl();
        if ((commodity.getCommodityname() != null) && (!(commodity.getCommodityname().equals("")))) {
            shouldChangeNum++;
            changeNum += merchantDaoImpl.change(commodity.getCommodityid(), "commodityname", commodity);
        }
        if ((commodity.getCommoditystocks() != 0)) {
            shouldChangeNum++;
            changeNum += merchantDaoImpl.change(commodity.getCommodityid(), "commoditystocks", commodity);
        }
        if ((commodity.getCommodityprice() != 0.00)) {
            shouldChangeNum++;
            changeNum += merchantDaoImpl.change(commodity.getCommodityid(), "commodityprice", commodity);
        }
        if ((commodity.getCommoditycharacteristics() != null) && (!(commodity.getCommoditycharacteristics().equals("")))) {
            shouldChangeNum++;
            changeNum += merchantDaoImpl.change(commodity.getCommodityid(), "commoditycharacteristics", commodity);
        }
        if ((shouldChangeNum != changeNum) || (changeNum == 0)) {
            return false;
        } else {
            return true;
        }

    }

    @Override
    public List<Commodity> show() {
        MerchantDaoImpl merchantDaoImpl = new MerchantDaoImpl();
        return merchantDaoImpl.show();
    }

    @Override
    public int soldOut(int commodityid) {
        MerchantDaoImpl merchantDaoImpl = new MerchantDaoImpl();
        return merchantDaoImpl.soldOut(commodityid);
    }

    @Override
    public int putAwayCommodity(Commodity commodity) {
        MerchantDaoImpl merchantDaoImpl = new MerchantDaoImpl();
        return merchantDaoImpl.putAwayCommodity(commodity);
    }

    @Override
    public int changeCommodityPhoto(Commodity commodity) {
        MerchantDaoImpl merchantDaoImpl = new MerchantDaoImpl();
        return merchantDaoImpl.changeCommodityPhoto(commodity);
    }
}
