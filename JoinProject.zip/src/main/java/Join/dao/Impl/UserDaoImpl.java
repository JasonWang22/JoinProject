package Join.dao.Impl;

import Join.dao.Sql.UserSql;
import Join.dao.UserDao;
import Join.entity.UserAndMerchant;
import Join.utils.DruidUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UserDaoImpl implements UserDao {

    @Override
    public int login(UserAndMerchant user) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        int code = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.loginCheckUser);
            preparedStatement.setString(1, user.getUsername());
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                code += resultSet.getInt("usernum");
            }
            if (code != 0) {
                preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.loginCheckPwd);
                preparedStatement.setString(1,user.getUsername());
                preparedStatement.setString(2,user.getPassword());
                resultSet = preparedStatement.executeQuery();
                while (resultSet.next()) {
                    code += resultSet.getInt("Tusernum");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭资源
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return code;
    }

    @Override
    public int register(UserAndMerchant user) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.register);
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getRealname());
            preparedStatement.setString(3, user.getQqmail());
            preparedStatement.setString(4, user.getTel());
            preparedStatement.setString(5, user.getPassword());
            preparedStatement.setString(6,"http://join.natapp1.cc:80/UserHeadprotrait/ff8ade3f-b150-43e3-9303-3d1362c27858.jpg");
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭资源
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public int cancel(UserAndMerchant user) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.cancel);
            preparedStatement.setString(1, user.getUsername());
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭资源
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public int change(String username, String filed, String informationChanged) {
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        int row = 0;
        try {
            connection = DruidUtil.getConnection();
            switch (filed) {
                case "username":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changeUsername);
                    break;
                case "realname":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changeRealname);
                    break;
                case "qqmail":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changeQqmail);
                    break;
                case "tel":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changeTel);
                    break;
                case "password":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changePassword);
                    break;
                case "userheadportrait":
                    preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.changeUserHeadportrait);
            }
            preparedStatement.setString(1, informationChanged);
            preparedStatement.setString(2, username);
            row = preparedStatement.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭资源
            try {
                DruidUtil.releaseDml(preparedStatement, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return row;
    }

    @Override
    public UserAndMerchant getUser(String username) {
        UserAndMerchant user = null;
        PreparedStatement preparedStatement = null;
        Connection connection = null;
        ResultSet resultSet = null;
        try {
            connection = DruidUtil.getConnection();
            preparedStatement = DruidUtil.getPreparedStatement(connection, UserSql.getUser);
            preparedStatement.setString(1, username);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                user = new UserAndMerchant();
                user.setUserid(resultSet.getInt("userid"));
                user.setUsername(resultSet.getString("username"));
                user.setRealname(resultSet.getString("realname"));
                user.setQqmail(resultSet.getString("qqmail"));
                user.setTel(resultSet.getString("tel"));
                user.setUserheadportrait(resultSet.getString("userheadportrait"));
                user.setSpend(resultSet.getDouble("spend"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            //关闭资源
            try {
                DruidUtil.releaseDql(preparedStatement, resultSet, connection);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return user;
    }

}
