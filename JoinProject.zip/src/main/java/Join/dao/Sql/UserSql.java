package Join.dao.Sql;

public class UserSql {

    public static String loginCheckUser = "select count(*) usernum from (select * from joinuser where username =? ) loginuser";

    public static String loginCheckPwd = "select count(*) Tusernum from (select * from joinuser where username =? and password =?) Tloginuser";

    public static String register = "insert into joinuser(username, realname, qqmail, tel, password, userheadportrait) values (?,?,?,?,?,?)";

    public static String cancel = "delete from joinuser where username =?";

    public static String changeUsername = "update joinuser set username =? where username =?";

    public static String changeRealname = "update joinuser set realname =? where username =?";

    public static String changeQqmail = "update joinuser set qqmail =? where username =?";

    public static String changeTel = "update joinuser set tel =? where username =?";

    public static String changePassword = "update joinuser set password =? where username =?";

    public static String changeUserHeadportrait = "update joinuser set userheadportrait =? where username =?";

    public static String getUser = "select * from joinuser where username =?";

}
